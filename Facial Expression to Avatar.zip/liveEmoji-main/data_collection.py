import mediapipe as mp 
import numpy as np 
import cv2 
def data_collection():
	cap = cv2.VideoCapture(0)

	name = input("Enter the name of the data : ")

	holistic = mp.solutions.holistic #it can track human face expressions
	hands = mp.solutions.hands
	holis = holistic.Holistic() #creates an instance for holistic
	drawing = mp.solutions.drawing_utils #used to draw landmarks 

	X = [] #empty set to store extracted features
	data_size = 0 #to keep track of the data samples extracted

	while True:
		lst = [] # store extracted feature for each frame

		_, frm = cap.read()

		frm = cv2.flip(frm, 1) #flips the frame horizontally

		res = holis.process(cv2.cvtColor(frm, cv2.COLOR_BGR2RGB)) #processes each frame


		if res.face_landmarks: #check for landmark detection in frame
			for i in res.face_landmarks.landmark: #iterate over each landmark detected on face
				lst.append(i.x - res.face_landmarks.landmark[1].x)
				lst.append(i.y - res.face_landmarks.landmark[1].y)

			if res.left_hand_landmarks:
				for i in res.left_hand_landmarks.landmark:
					lst.append(i.x - res.left_hand_landmarks.landmark[8].x)
					lst.append(i.y - res.left_hand_landmarks.landmark[8].y)
			else:
				for i in range(42):
					lst.append(0.0)

			if res.right_hand_landmarks:
				for i in res.right_hand_landmarks.landmark:
					lst.append(i.x - res.right_hand_landmarks.landmark[8].x)
					lst.append(i.y - res.right_hand_landmarks.landmark[8].y)
			else:
				for i in range(42):
					lst.append(0.0)


			X.append(lst)
			data_size = data_size+1

		drawing.draw_landmarks(frm, res.face_landmarks, holistic.FACEMESH_CONTOURS)
		drawing.draw_landmarks(frm, res.left_hand_landmarks, hands.HAND_CONNECTIONS)
		drawing.draw_landmarks(frm, res.right_hand_landmarks, hands.HAND_CONNECTIONS)

		cv2.putText(frm, str(data_size), (50,50), cv2.FONT_HERSHEY_SIMPLEX, 1, (0,255,0),2)

		cv2.imshow("window", frm)

		if cv2.waitKey(1) == 27 or data_size>99:
			cv2.destroyAllWindows()
			cap.release()
			break                 # closes the open cv 


	np.save(f"{name}.npy", np.array(X))
	print(np.array(X).shape)
